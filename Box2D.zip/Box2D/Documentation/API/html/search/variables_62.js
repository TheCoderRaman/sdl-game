var searchData=
[
  ['b2_5fversion',['b2_version',['../b2_settings_8h.html#a3a20e3b6a8b05633d911fea031f7a44f',1,'b2Settings.cpp']]],
  ['bodya',['bodyA',['../structb2_joint_def.html#a8cd54c93da396be75a9788f2c6897f05',1,'b2JointDef']]],
  ['bodyb',['bodyB',['../structb2_joint_def.html#aa4f4dee2fbcd12187b19506b60e68e3d',1,'b2JointDef']]],
  ['bullet',['bullet',['../structb2_body_def.html#a7c0047c9a98a1d20614eeddcdbce7586',1,'b2BodyDef']]]
];
